The MCF5235 port is deprecated. The last FreeRTOS version that includes this port is 10.4.3.

